import express from "express";
import UsuarioController from "../controllers/usuariocontroller.js";

const router = express.Router();
const crtl = new UsuarioController();

router.post("/criar", crtl.criar);

export default router;