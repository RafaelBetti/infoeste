import UsuarioModel from "../model/usuario.model.js";

export default class UsuarioController{
    async criar (req, res){
        let {nome, email, idade}=req.body;

        if(nome && email && idade){
            let usuariomodel=new UsuarioModel("",nome, email, idade);
            let usuariocriar=await usuariomodel.criar();

            if(usuariocriar){
                res.status(200).json({
                    ok: true,
                    data: "Usuário criado com sucesso!"
                });
            }else{
                res.status(404).json({
                    ok: false,
                    msg: "Usuário não encontrado!"
                });
            }
        }else{
            res.status(400).json({
                ok: false,
                msg: "Parametros inválidos!"
            });
        }
    }
}